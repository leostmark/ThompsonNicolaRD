{
  "offlineBasemaps": null,
  "templatePath": null,
  "views": [
    {
      "expandedShells": true,
      "name": "IWantToMenuSectionView"
    },
    {
      "expandedShells": false,
      "name": "LookAndFeelSectionView"
    },
    {
      "expandedShells": false,
      "name": "ApplicationSectionView"
    },
    {
      "expandedShells": true,
      "name": "AccessibilitySectionView"
    },
    {
      "expandedShells": false,
      "name": "OfflineSectionView"
    },
    {
      "expandedShells": true,
      "name": "GeolocateSectionView"
    },
    {
      "expandedShells": false,
      "name": "HomePanelSectionView"
    },
    {
      "expandedShells": true,
      "name": "ToolbarSectionView"
    },
    {
      "expandedShells": true,
      "name": "ToolBehaviorSectionView"
    },
    {
      "expandedShells": false,
      "name": "InstantSearchSectionView"
    },
    {
      "expandedShells": false,
      "name": "LayerListSectionView"
    },
    {
      "expandedShells": false,
      "name": "PushpinsSectionView"
    },
    {
      "expandedShells": false,
      "name": "OptimizerIntegrationSectionView"
    },
    {
      "expandedShells": false,
      "name": "CollaborationSectionView"
    },
    {
      "expandedShells": true,
      "name": "MapWidgetsSectionView"
    },
    {
      "expandedShells": false,
      "name": "MapSectionView"
    },
    {
      "expandedShells": false,
      "name": "InsightIntegrationSectionView"
    },
    {
      "expandedShells": true,
      "name": "MapContextMenuSectionView"
    },
    {
      "expandedShells": false,
      "name": "ContextMenusSectionView"
    },
    {
      "expandedShells": false,
      "name": "ContextMenuBaseSectionView"
    },
    {
      "expandedShells": false,
      "name": "CoordinateActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "CoordinatesListActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "LayerActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "LayerListActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "LegendActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "FeatureActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "MapTipActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "ProjectActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "ProjectsActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "ResultsListActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "ResultsTableActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "GlobalMenuConfigSectionView"
    },
    {
      "expandedShells": false,
      "name": "FooterMenuConfigSectionView"
    },
    {
      "expandedShells": false,
      "name": "SelectionActionsSectionView"
    },
    {
      "expandedShells": true,
      "name": "MeasurementSectionView"
    },
    {
      "expandedShells": false,
      "name": "MapServiceActionsSectionView"
    },
    {
      "expandedShells": true,
      "name": "QueryActionsSectionView"
    },
    {
      "expandedShells": true,
      "name": "FilterBuilderActionsSectionView"
    },
    {
      "expandedShells": true,
      "name": "FilterActionsSectionView"
    },
    {
      "expandedShells": true,
      "name": "QueryBuilderActionsSectionView"
    },
    {
      "expandedShells": false,
      "name": "WorkflowSectionView"
    }
  ]
}